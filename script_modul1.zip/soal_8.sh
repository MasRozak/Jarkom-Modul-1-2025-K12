#!bin/bash

wget -O cuaca.zip --no-check-certificate https://drive.usercontent.google.com/u/0/uc?id=11ra_yTV_adsPIXeIPMSt0vrxCBZu0r33&export=download
ftp 192.217.1.1
#login : ainur
#password : ainur123
put cuaca.zip