#!/bin/bash
# Update package lists
echo "nameserver 192.168.122.1" > /etc/resolv.conf

ping google.com