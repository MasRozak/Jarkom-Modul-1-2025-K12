#!/bin/bash
ping 192.217.1.1 -c 100
